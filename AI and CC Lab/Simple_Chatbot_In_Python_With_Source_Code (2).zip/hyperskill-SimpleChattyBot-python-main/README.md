# hyperskill-SimpleChattyBot-python
A simple bot that will help you in your learning and make it more fun.  

## Syntax
```
bot.py
```

## Stages
**Stage #1: Chatty Bot welcomes you**   
Teach your assistant to introduce itself in the console.

**Stage #2: Print your name**   
Introduce yourself to the bot.

**Stage #3: Guess the age**   
Use your knowledge of strings and numbers to make the assistant guess your age. 

**Stage #4: Learning numbers**   
Your assistant is old enough to learn how to count. And you are experienced enough to apply a for loop at this stage! 

**Stage #5: Multiple Choice**
At this point, the assistant will be able to check your knowledge and ask multiple-choice questions. Add some functions to your code and make the stage even better. 
